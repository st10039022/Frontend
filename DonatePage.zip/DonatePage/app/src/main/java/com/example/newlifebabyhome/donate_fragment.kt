package com.example.newlifebabyhome

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment

class DonateFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_donate, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Back button (pops to Dashboard)
        val backButton = view.findViewById<ImageView>(R.id.buttonBack)
        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        // Zapper button (shows Zapper QR pop-up)
        val btnZapper = view.findViewById<Button>(R.id.btnZapper)
        btnZapper.setOnClickListener {
            showZapperPopup()
        }

        // EFT button (shows EFT details pop-up)
        val btnEFT = view.findViewById<Button>(R.id.btnEFT)
        btnEFT.setOnClickListener {
            showEFTPopup()
        }

        // Babychino button (shows Babychino image pop-up)
        val btnBabychino = view.findViewById<Button>(R.id.btnBabychino)
        btnBabychino.setOnClickListener {
            showBabychinoPopup()
        }

        // Bottom buttons (placeholders; add your logic here)
        val generateQRButton = view.findViewById<Button>(R.id.buttonGenerateQR)
        generateQRButton.setOnClickListener {
            // TODO: Implement generate QR logic (e.g., based on custom amount)
        }

        val otherPaymentButton = view.findViewById<Button>(R.id.buttonOtherPayment)
        otherPaymentButton.setOnClickListener {
            // TODO: Implement other payments logic
        }

        // Optional: Hide the static QR section in main layout (since pop-ups handle it)
        // If your main XML has a CardView for QR, add android:id="@+id/qrCardView" to it, then:
        // val qrCard = view.findViewById<View>(R.id.qrCardView)
        // qrCard?.visibility = View.GONE
    }

    // Zapper pop-up (QR image + text)
    private fun showZapperPopup() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Zapper Payment")

        // Inflate custom pop-up layout
        val popupView = layoutInflater.inflate(R.layout.popup_zapper, null)
        builder.setView(popupView)

        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    // EFT pop-up (banking details text)
    private fun showEFTPopup() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("EFT Banking Details")

        // Inflate custom pop-up layout
        val popupView = layoutInflater.inflate(R.layout.popup_eft, null)
        builder.setView(popupView)

        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    // Babychino pop-up (image + text)
    private fun showBabychinoPopup() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("BabyChino Payment")

        // Inflate custom pop-up layout
        val popupView = layoutInflater.inflate(R.layout.popup_babychino, null)
        builder.setView(popupView)

        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }
}
